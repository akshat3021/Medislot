// Core booking logic
